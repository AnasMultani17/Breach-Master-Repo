import mongoose from 'mongoose';

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/test');
    console.log('✅ MongoDB Connected');
  } catch (error) {
    console.log('⚠️ MongoDB not running - continuing without DB');
  }
};

export default connectDB;
