import multer from "multer";
import path from "path";
import fs from "fs";

// 1. Use absolute path so upload works regardless of process.cwd()
const tempDir = path.join(process.cwd(), "public", "temp");
if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true });
}

// 2. Configure Disk Storage
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        // Save files temporarily to the local public/temp folder
        cb(null, tempDir);
    },
    filename: function (req, file, cb) {
        // Create a unique filename to prevent overwriting if two people upload at the same millisecond
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        // e.g., pdfFile-1683929392-resume.pdf
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

// 3. Security: Strict File Filter (Only PDFs allowed)
const fileFilter = (req, file, cb) => {
    if (file.mimetype === "application/pdf") {
        cb(null, true); // Accept the file
    } else {
        cb(new Error("Invalid file type. Only PDF files are allowed!"), false); // Reject the file
    }
};

// 4. Export the configured Multer instance
export const upload = multer({ 
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 5 * 1024 * 1024 // 5 MB limit (adjust if needed)
    }
});