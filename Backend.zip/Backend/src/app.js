// src/app.js - ULTRA SIMPLE (NO WILDCARDS)
import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import userRoutes from './routes/user.route.js';
import jobRouter from './routes/job.routes.js'; // Ensure this is imported

const app = express();

// Middleware
app.use(cookieParser());
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: "16kb" }));
app.use(express.urlencoded({ extended: true, limit: "16kb" }));

// Health check ONLY
app.get('/health', (req, res) => {
  res.json({ status: 'OK', message: 'Auth server ready' });
});

// User routes
app.use('/api/v1/users', userRoutes);
app.use("/api/v1/jobs", jobRouter);

// NEW: Added this specifically to handle your frontend URL for the refresh button!
app.use('/api/candidates', userRoutes); 

// NO WILDCARD ROUTES - LET EXPRESS HANDLE 404 NATURALLY

export { app };