// Backend/src/models/user.model.js
import mongoose, { Schema } from "mongoose";
import bcrypt from "bcryptjs";

const userSchema = new Schema({
  // ==========================================
  // 1. AUTHENTICATION & CORE DETAILS
  // ==========================================
  email: {
    type: String,
    required: [true, "Email is required"],
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    // Made optional so email-parsed resumes can be saved without crashing
    required: false, 
    minlength: [6, "Password must be at least 6 characters"],
    select: false
  },
  fullName: { type: String },
  phone: { type: String },

  // ==========================================
  // 2. ATS & RESUME DATA
  // ==========================================
  sourcePlatforms: [{ type: String }],
  originalResumeUrls: [{ type: String }],
  
  location: {
    city: { type: String },
    state: { type: String },
    country: { type: String }
  },
  
  totalExperienceYears: { type: Number, default: 0 },
  skills: [{ type: String }],
  
  experience: [{
    company: String,
    role: String,
    startDate: Date,
    endDate: Date,
    techstack: [{ type: String }],
    years_worked: String,
    description: String
  }],
  
  education: [{
    institution: String,
    degree: String,
    from: Number,
    to: Number,
    score: String
  }],

  // ==========================================
  // 3. HR JOB PIPELINE TRACKING
  // ==========================================
  applied_role: { 
    type: String, 
    lowercase: true 
  },
  applicationStage: {
    type: String,
    enum: ['Applied', 'Round 1', 'Round 2', 'Hired', 'Rejected'],
    default: 'Applied'
  }

}, { timestamps: true, collection: 'candidates' });


// ==========================================
// METHODS & MIDDLEWARE
// ==========================================

// Hash password before saving
userSchema.pre("save", async function(next) {
  // If password wasn't modified OR doesn't exist (e.g., auto-created from email), skip hashing
  if (!this.isModified("password") || !this.password) return next();
  
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

// Check password
userSchema.methods.isPasswordCorrect = async function(password) {
  // Safety check in case a user without a password tries to log in
  if (!this.password) return false; 
  return await bcrypt.compare(password, this.password);
};

export const User = mongoose.model("User", userSchema);