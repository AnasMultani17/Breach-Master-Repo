import mongoose from "mongoose";

const jobSchema = new mongoose.Schema({
    title: { 
        type: String, 
        required: true,
        lowercase: true // Automatically saves "Software Dev" as "software dev"
    },
    status: {
        type: String,
        enum: ['Active', 'Completed'],
        default: 'Active'
    }
}, { timestamps: true });

export const Job = mongoose.model("Job", jobSchema);