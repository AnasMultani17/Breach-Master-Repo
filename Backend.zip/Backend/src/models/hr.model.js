import mongoose, { Schema } from "mongoose";
import bcrypt from "bcryptjs";

const hrSchema = new Schema(
  {
    firstName: {
      type: String,
      required: [true, "First name is required"],
      trim: true,
    },
    lastName: {
      type: String,
      required: [true, "Last name is required"],
      trim: true,
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: [true, "Password is required"],
      minlength: [6, "Password must be at least 6 characters"],
      select: false,
    },
    appPassword: {
      type: String,
      required: [true, "App password is required"],
      minlength: [6, "App password must be at least 6 characters"],
      select: false,
    },
  },
  {
    timestamps: true,
    collection: "hr",
  }
);

hrSchema.pre("save", async function (next) {
  if (this.isModified("password")) {
    this.password = await bcrypt.hash(this.password, 10);
  }

  if (this.isModified("appPassword")) {
    this.appPassword = await bcrypt.hash(this.appPassword, 10);
  }

  next();
});

hrSchema.methods.isPasswordCorrect = async function (password) {
  return await bcrypt.compare(password, this.password);
};

export const Hr = mongoose.model("Hr", hrSchema);

