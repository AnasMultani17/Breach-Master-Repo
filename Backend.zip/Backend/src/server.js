import dotenv from 'dotenv';
dotenv.config();

import connectDB from './utils/connectDB.js';
import { app } from './app.js';

const PORT = process.env.PORT || 8080;

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`✅ Server running on port ${PORT}`);
  });
}).catch((error) => {
  console.error('❌ Server failed to start:', error);
});
