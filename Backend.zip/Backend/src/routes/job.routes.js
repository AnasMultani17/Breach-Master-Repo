import { Router } from "express";
import {deleteJobAndCandidates, getJobs, createJob, endJob } from "../controllers/job.controller.js";

const router = Router();

router.route("/").get(getJobs).post(createJob);
router.route("/:id/end").put(endJob);
router.route("/:id").delete(deleteJobAndCandidates);

export default router;