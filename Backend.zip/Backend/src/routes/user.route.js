// src/routes/user.route.js
import { Router } from 'express';
import { 
    registerUser, 
    loginUser, 
    getAllResumes, 
    updateCandidateStage,
    syncCandidates,
    syncHrmsCandidates,
    getCandidatesByIds,
    getCandidatesForAiMatch,
    uploadAndExtractResume// 1. IMPORT THE HRMS FUNCTION
} from '../controllers/user.controller.js';
import { upload } from "../middlewares/multer.middleware.js";

const router = Router();

router.route("/stage/:id").put(updateCandidateStage);
router.route("/resumes").get(getAllResumes);
router.route("/batch").post(getCandidatesByIds);
// Add getCandidatesForAiMatch to your imports
router.route("/ai-match-filter").get(getCandidatesForAiMatch);
router.route("/upload-manual").post(
    upload.single("pdfFile"), 
    uploadAndExtractResume
);

// --- SYNC ROUTES ---
router.route("/sync").get(syncCandidates); 
router.route("/sync-hrms").get(syncHrmsCandidates); // 2. ADD THE HRMS ROUTE

// --- AUTH ROUTES ---
router.post('/register', registerUser);
router.post('/login', loginUser);

export default router;