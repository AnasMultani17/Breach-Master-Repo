import { Job } from "../models/job.model.js";
// Backend/src/controllers/job.controller.js
import { User } from "../models/user.model.js"; // MUST import User to delete candidates!

// ==========================================
// DELETE JOB AND WIPE ALL CANDIDATES
// ==========================================
export const deleteJobAndCandidates = async (req, res) => {
    try {
        const { id } = req.params;
        
        // 1. Find the job first so we know what title we are looking for
        const job = await Job.findById(id);
        if (!job) {
            return res.status(404).json({ message: "Job not found" });
        }

        const jobTitle = job.title.toLowerCase();

        // 2. Delete ALL candidates in the database who applied for this specific role
        console.log(`>>> Wiping all candidates who applied for: ${jobTitle}`);
        await User.deleteMany({ applied_role: jobTitle });

        // 3. Delete the Job itself
        console.log(`>>> Deleting job: ${jobTitle}`);
        await Job.findByIdAndDelete(id);

        res.status(200).json({ 
            success: true, 
            message: "Job and all associated candidates were permanently deleted." 
        });

    } catch (error) {
        console.error("[-] Error deleting job and candidates:", error);
        res.status(500).json({ message: "Server error while deleting." });
    }
};

// ... (keep your other functions like createJob, getAllJobs, etc.)
export const getJobs = async (req, res) => {
    try {
        const jobs = await Job.find();
        res.status(200).json(jobs);
    } catch (error) {
        res.status(500).json({ message: "Error fetching jobs" });
    }
};

export const createJob = async (req, res) => {
    try {
        const { title } = req.body;
        const newJob = await Job.create({ title });
        res.status(201).json(newJob);
    } catch (error) {
        res.status(500).json({ message: "Error creating job" });
    }
};

export const endJob = async (req, res) => {
    try {
        const { id } = req.params;
        const updatedJob = await Job.findByIdAndUpdate(id, { status: 'Completed' }, { new: true });
        res.status(200).json(updatedJob);
    } catch (error) {
        res.status(500).json({ message: "Error ending job" });
    }
};