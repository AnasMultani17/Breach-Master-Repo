// controllers/user.controller.js
import { exec } from "child_process"; // NEW IMPORT REQUIRED FOR PYTHON
import path from "path";              // NEW IMPORT REQUIRED FOR PYTHON
import asyncHandler from "../utils/asyncHandler.js";
import ApiError from "../utils/ApiError.js";
import ApiResponse from "../utils/ApiResponse.js";
import { Hr } from "../models/hr.model.js";
import jwt from "jsonwebtoken";
// 1. We import the Model (User)
import { User } from "../models/user.model.js"; 
import axios from "axios";
import { v2 as cloudinary } from "cloudinary";
import fs from "fs"; // Required to delete the local file after Cloudinary upload

cloudinary.config({ 
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME, 
  api_key: process.env.CLOUDINARY_API_KEY, 
  api_secret: process.env.CLOUDINARY_API_SECRET 
});

export const getAllResumes = async (req, res) => {
    try {
        const { role } = req.query; // Grabs the role from the frontend URL
        
        let query = {};
        if (role) {
            query.applied_role = role.toLowerCase();
        }

        const resumes = await User.find(query);
        res.status(200).json(resumes);
    } catch (error) {
        res.status(500).json({ message: "Server Error" });
    }
};

export const updateCandidateStage = async (req, res) => {
    try {
        const { id } = req.params;
        const { stage } = req.body; 

        const updatedCandidate = await User.findByIdAndUpdate(
            id, 
            { applicationStage: stage }, 
            { new: true }
        );
        res.status(200).json(updatedCandidate);
    } catch (error) {
        res.status(500).json({ message: "Error updating candidate stage" });
    }
};

const generateAccessToken = (userId) => {
  return jwt.sign({ _id: userId }, process.env.ACCESS_TOKEN_SECRET, {
    expiresIn: "7d"
  });
};

// Register HR
export const registerUser = asyncHandler(async (req, res) => {
  const { firstName, lastName, email, password, appPassword } = req.body;
  
  if (!firstName || !lastName || !email || !password || !appPassword) {
    throw new ApiError(400, "First name, last name, email, password and app password are required");
  }

  const existingHr = await Hr.findOne({ email });
  if (existingHr) {
    throw new ApiError(409, "HR with this email already exists");
  }

  const hr = await Hr.create({ firstName, lastName, email, password, appPassword });
  const accessToken = generateAccessToken(hr._id);

  const hrInfo = { _id: hr._id, firstName: hr.firstName, lastName: hr.lastName, email: hr.email };

  return res.status(201).json(
    new ApiResponse(201, hrInfo, "HR registered successfully", true)
  );
});

// Login HR
export const loginUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  
  if (!email || !password) {
    throw new ApiError(400, "Email and password are required");
  }

  const hr = await Hr.findOne({ email }).select("+password");
  if (!hr) {
    throw new ApiError(401, "Invalid credentials");
  }

  const isPasswordValid = await hr.isPasswordCorrect(password);
  if (!isPasswordValid) {
    throw new ApiError(401, "Invalid credentials");
  }

  const accessToken = generateAccessToken(hr._id);
  const hrInfo = { _id: hr._id, email: hr.email };

  // Set token in cookie + response
  res.cookie("accessToken", accessToken, {
    httpOnly: true,
    secure: false, // Set true in production with HTTPS
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
  });

  return res.status(200).json(
    new ApiResponse(200, { ...hrInfo, accessToken }, "Login successful", true)
  );
});

// ==========================================
// 1. SYNC EMAILS (GMAIL PIPELINE)
// ==========================================
export const syncCandidates = async (req, res) => {
    try {
        console.log("\n>>> [1/4] Initiating GMAIL sync...");

        // FETCH FROM LOCALHOST PYTHON SCRIPT
        const pythonResponse = await axios.get("http://127.0.0.1:5000/api/fetch-resume",{timeout: 30000000});
        const emailJsonData = pythonResponse.data; 

        if (!emailJsonData.pdf_url || emailJsonData.pdf_url.trim() === "") {
            console.log("[-] Email found, but no PDF attached. Skipping.");
            return res.status(200).json({ success: true, message: "No PDF attached! Skipping." });
        }

        console.log(`>>> [2/4] PDF URL: ${emailJsonData.pdf_url}`);
        console.log(">>> [3/4] Sending to Extraction API at 192.168.1.5...");

        // --- THE FIX: STRICT CROSS-IP AXIOS CONFIG ---
        const payloadToExtract = {
            email_text: emailJsonData.email_text || "",
            pdf_url: emailJsonData.pdf_url || ""
        };

        const extractionResponse = await axios.post(
            "https://data-extract-breach.onrender.com/extract/email", 
            payloadToExtract,
            {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                timeout: 30000000 // 30 seconds to allow the AI to think without Axios crashing!
            }
        );
        // ----------------------------------------------

        let aiData = extractionResponse.data; 

        // ROBUST DATA NORMALIZER
        if (typeof aiData === "string") {
            try { aiData = JSON.parse(aiData.replace(/```json/g, "").replace(/```/g, "").trim()); } 
            catch (err) { aiData = {}; }
        }
        if (aiData.candidate) aiData = aiData.candidate;
        if (aiData.data) aiData = aiData.data;

        if (!aiData.email || aiData.email.trim() === "") {
            const emailMatch = emailJsonData.email_text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
            aiData.email = emailMatch ? emailMatch[0].toLowerCase() : `needs_review_${Date.now()}@example.com`;
        }

        if (!aiData.applied_role || aiData.applied_role.trim() === "") {
            const subject = emailJsonData.email_text.match(/Subject:\s*(.*)/i)?.[1]?.toLowerCase() || "";
            if (subject.includes("software") || subject.includes("sde")) aiData.applied_role = "software development";
            else if (subject.includes("data")) aiData.applied_role = "data science";
            else aiData.applied_role = "general application"; 
        }

        aiData.originalResumeUrls = [emailJsonData.pdf_url]; 
        aiData.sourcePlatforms = ["Gmail_Auto_Sync"];
        aiData.applicationStage = "Applied";
        if (!aiData.fullName) aiData.fullName = "New Candidate";
        
        delete aiData.createdAt;
        delete aiData.updatedAt;

        console.log(">>> [4/4] Saving to database...");
        const savedCandidate = await User.create(aiData);
        console.log(`>>> ✅ Success! Saved: ${savedCandidate.email}`);
        await axios.post('http://192.168.1.5:5000/api/sync/all');
        return res.status(200).json({ success: true, candidate: savedCandidate });

    } catch (error) {
        console.error("[-] Gmail Sync Error:");
        if (error.response) {
            if (error.response.status === 404) return res.status(200).json({ success: true, message: "No new emails." });
            console.error(`    Status: ${error.response.status} | Data:`, error.response.data);
        } else if (error.code === 'ECONNREFUSED') {
            console.error("    NETWORK ERROR: Could not connect to the IP address! Is the server running?");
        } else {
            console.error(`    ${error.message}`);
        }
        return res.status(200).json({ success: false, message: "Sync failed safely.", error: error.message });
    }
};


// ==========================================
// 2. SYNC HRMS CANDIDATES (HRMS PIPELINE)
// ==========================================
export const syncHrmsCandidates = async (req, res) => {
    try {
        console.log("\n>>> [HRMS 1/4] Initiating HRMS sync...");

        // FETCH FROM HRMS IP
        console.log(">>> [HRMS 2/4] Fetching from HRMS at 192.168.1.8:5000...");
        const hrmsResponse = await axios.get("http://192.168.1.8:5000/api/candidates/sync");
        const hrmsJsonDat = hrmsResponse.data; 
        const hrmsJsonData=hrmsJsonDat[0];
        console.log(hrmsJsonData.pdf_url);

        if (!hrmsJsonData.pdf_url || hrmsJsonData.pdf_url.trim() === "") {
            console.log("[-] [HRMS DEBUG] HRMS data found, but no PDF attached. Skipping.");
            return res.status(200).json({ success: true, message: "No PDF attached! Skipping." });
        }

        console.log(`>>> [HRMS 3/4] PDF URL: ${hrmsJsonData.pdf_url}`);
        console.log(">>> [HRMS 4/4] Sending to Extraction API at 192.168.1.5...");
        
        // --- THE FIX: STRICT CROSS-IP AXIOS CONFIG ---
        const payloadToExtract = {
            email_text: hrmsJsonData.email_text || "",
            pdf_url: hrmsJsonData.pdf_url || ""
        };

        const extractionResponse = await axios.post(
            "https://data-extract-breach.onrender.com/extract/email", 
            payloadToExtract,
            {
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            }
        );
        // ----------------------------------------------

        let aiData = extractionResponse.data; 

        // ROBUST DATA NORMALIZER
        if (typeof aiData === "string") {
            try { aiData = JSON.parse(aiData.replace(/```json/g, "").replace(/```/g, "").trim()); } 
            catch (err) { aiData = {}; }
        }
        if (aiData.candidate) aiData = aiData.candidate;
        if (aiData.data) aiData = aiData.data;

        if (!aiData.email || aiData.email.trim() === "") {
            const emailMatch = hrmsJsonData.email_text ? hrmsJsonData.email_text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/) : null;
            aiData.email = emailMatch ? emailMatch[0].toLowerCase() : `hrms_review_${Date.now()}@example.com`;
        }

        if (!aiData.applied_role || aiData.applied_role.trim() === "") {
            const subject = hrmsJsonData.email_text ? hrmsJsonData.email_text.match(/Subject:\s*(.*)/i)?.[1]?.toLowerCase() : "";
            if (subject && (subject.includes("software") || subject.includes("sde"))) aiData.applied_role = "software development";
            else if (subject && subject.includes("data")) aiData.applied_role = "data science";
            else aiData.applied_role = "general application"; 
        }

        aiData.originalResumeUrls = [hrmsJsonData.pdf_url]; 
        aiData.sourcePlatforms = ["External_HRMS"]; 
        aiData.applicationStage = "Applied";
        if (!aiData.fullName) aiData.fullName = "HRMS Imported Candidate";
        
        delete aiData.createdAt;
        delete aiData.updatedAt;

        console.log(">>> [HRMS 5/5] Saving to database...");
        const savedCandidate = await User.create(aiData);
        console.log(`>>> ✅ [HRMS] Success! Saved: ${savedCandidate.email}`);
        await axios.post('http://192.168.1.5:5000/api/sync/all');
        return res.status(200).json({ success: true, candidate: savedCandidate });

    } catch (error) {
        console.error("[-] HRMS Sync Error:");
        if (error.response) {
            if (error.response.status === 404) return res.status(200).json({ success: true, message: "No new candidates." });
            console.error(`    Status: ${error.response.status} | Data:`, error.response.data);
        } else if (error.code === 'ECONNREFUSED') {
            console.error("    NETWORK ERROR: Could not connect to the HRMS IP or Extraction IP! Ensure devices are on the same network.");
        } else {
            console.error(`    ${error.message}`);
        }
        return res.status(200).json({ success: false, message: "HRMS Sync failed safely.", error: error.message });
    }
};
// ==========================================
// FETCH MULTIPLE CANDIDATES BY IDs (For AI Match)
// ==========================================
export const getCandidatesByIds = async (req, res) => {
    try {
        const { ids } = req.body; 

        // Safety check to ensure we received an array
        if (!ids || !Array.isArray(ids)) {
            return res.status(400).json({ message: "Please provide an array of candidate IDs." });
        }

        console.log(`>>> Fetching full profiles for ${ids.length} AI matched candidates...`);

        // Tell MongoDB to find all users whose _id is IN the array of IDs we provided
        const candidates = await User.find({ _id: { $in: ids } });

        res.status(200).json(candidates);

    } catch (error) {
        console.error("[-] Error fetching batch candidates:", error.message);
        res.status(500).json({ message: "Server error fetching matched candidates." });
    }
};
// Backend/src/controllers/user.controller.js

// ==========================================
// FETCH CANDIDATES BY ROLE & STAGE (For AI Input)
// ==========================================
export const getCandidatesForAiMatch = async (req, res) => {
    try {
        const { role } = req.query; // e.g., "Software Development"

        if (!role) {
            return res.status(400).json({ message: "Role is required" });
        }

        console.log(`>>> Filtering DB for AI: Role="${role.toLowerCase()}" & Stage="Applied"`);

        // Find candidates where applied_role matches (lowercase) AND stage is 'Applied'
        const candidates = await User.find({
            applied_role: role.toLowerCase(),
            applicationStage: "Applied"
        });

        // Return only the data the AI needs to keep the payload light
        res.status(200).json(candidates);

    } catch (error) {
        console.error("[-] Error fetching filtered candidates for AI:", error);
        res.status(500).json({ message: "Server error" });
    }
};

// Upload PDF to Cloudinary only; return the PDF URL.
export const uploadAndExtractResume = async (req, res) => {
    const absolutePath = req.file?.path
        ? (path.isAbsolute(req.file.path) ? req.file.path : path.join(process.cwd(), req.file.path))
        : null;
    try {
        if (!req.file) {
            return res.status(400).json({ message: "PDF file is required." });
        }

        if (!absolutePath || !fs.existsSync(absolutePath)) {
            return res.status(400).json({ message: "Uploaded file not found on server." });
        }

        const cloudName = process.env.CLOUDINARY_CLOUD_NAME?.trim();
        const apiKey = process.env.CLOUDINARY_API_KEY?.trim();
        const apiSecret = process.env.CLOUDINARY_API_SECRET?.trim();
        if (!cloudName || !apiKey || !apiSecret) {
            return res.status(503).json({
                message: "Cloudinary is not configured. Add CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, and CLOUDINARY_API_SECRET to Backend .env",
                error: "Must supply api key"
            });
        }

        cloudinary.config({ cloud_name: cloudName, api_key: apiKey, api_secret: apiSecret });

        const fileBuffer = fs.readFileSync(absolutePath);
        const cloudinaryResponse = await new Promise((resolve, reject) => {
            const stream = cloudinary.uploader.upload_stream(
                { resource_type: "auto", folder: "resumes" },
                (err, result) => { if (err) reject(err); else resolve(result); }
            );
            stream.end(fileBuffer);
        });

        const pdfUrl = cloudinaryResponse.secure_url;

        if (absolutePath && fs.existsSync(absolutePath)) {
            try { fs.unlinkSync(absolutePath); } catch (_) {}
        }

        return res.status(200).json({
            success: true,
            pdfUrl,
            message: "PDF uploaded to Cloudinary."
        });
    } catch (error) {
        console.error("[-] Upload Error:", error);
        if (absolutePath && fs.existsSync(absolutePath)) {
            try { fs.unlinkSync(absolutePath); } catch (_) {}
        }
        return res.status(500).json({
            message: "Upload failed.",
            error: error.message || String(error)
        });
    }
};
