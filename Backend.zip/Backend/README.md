﻿# Social-Media-App-Backend-Deployment

> 🔗 **Deployed Link:**  
> [https://socialmediaapp-backend-1.onrender.com](https://socialmediaapp-backend-1.onrender.com)


